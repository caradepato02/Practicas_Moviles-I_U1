package com.example.eva1_6_idioma;

import androidx.appcompat.app.AppCompatActivity;

import android.media.session.MediaController;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {

    TextView txtViewIdioma;
    TextView txtViewNombre;
    TextView txtViewApellido;
    TextView txtViewEdad;

    EditText txtNombre;
    EditText txtApellido;
    EditText txtNumero;

    RadioGroup raGroupIdioma;
    RadioButton radButtonEs;
    RadioButton radButtonEn;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtViewIdioma = findViewById(R.id.txtViewdioma);
        txtViewNombre = findViewById(R.id.txtViewNombre);
        txtViewApellido = findViewById(R.id.txtViewApellido);
        txtViewEdad = findViewById(R.id.txtViewEdad);


        txtNombre = findViewById(R.id.txtNombre);
        txtApellido = findViewById(R.id.txtNombre);
        txtNumero = findViewById(R.id.txtNombre);

        raGroupIdioma = findViewById(R.id.raGroupIdioma);
        radButtonEn = findViewById(R.id.radButtonEn);
        radButtonEs = findViewById(R.id.radButtonEs);

        raGroupIdioma.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if (R.id.radButtonEs == checkedId){
            txtViewIdioma.setText(R.string.Idioma_es);
            radButtonEs.setText(R.string.espanol_es);
            radButtonEn.setText(R.string.ingles_es);
        }else{
            txtViewIdioma.setText(R.string.espanol_en);
            radButtonEs.setText(R.string.espanol_en);
            radButtonEn.setText(R.string.ingles_en);
        }
    }
}
